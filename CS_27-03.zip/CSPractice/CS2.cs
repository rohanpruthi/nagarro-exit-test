﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSPractice
{
    class CS2
    {
        public bool IsFileExist(file_name, folder_path)
        {
        }

    }
}

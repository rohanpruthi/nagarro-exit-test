﻿using System;

namespace CSPractice
{
    class Program
    {   /// <summary>
        /// This method inserts random 'A' and 'P' character in matrix
        /// of size N given by user. And calculates number of
        /// '+' and 'X' formed by character 'A'.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            int CountCross = 0; int CountPlus = 0;
            char[,] Arr;
            Console.WriteLine("Enter Value of N\n");
            int N = Convert.ToInt32(Console.ReadLine());
            Arr = new char[N, N];
            //Assigning random values to matrix
            Random random = new Random();
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (random.Next(0, 100) % 2 == 0)
                    {
                        Arr[i, j] = 'A';
                    }
                    else
                    {
                        Arr[i, j] = 'P';
                    }

                }
            }

            //To print the matrix generated after random insertion for debugging
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    Console.Write("{0} ", Arr[i, j]);
                }
                Console.Write(Environment.NewLine);
            }

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if ((i == 0) || (i == N - 1) || (j == 0) || (j == N - 1))
                    {
                        continue;
                    }
                    if ((Arr[i, j] == 'A') && (Arr[i, j + 1] == 'A') && (Arr[i, j - 1] == 'A') && (Arr[i + 1, j] == 'A') && (Arr[i - 1, j] == 'A'))
                    {
                        CountPlus = CountPlus + 1;
                        Console.WriteLine("{0} {1} {2} {3} {4}\n", (N * (i) + ((j) + 1)), (N * (i) + ((j + 1) + 1)), (N * (i) + ((j - 1) + 1)), (N * (i + 1) + ((j) + 1)), (N * (i - 1) + ((j) + 1)));
                    }
                    if ((Arr[i, j] == 'A') && (Arr[i - 1, j - 1] == 'A') && (Arr[i - 1, j + 1] == 'A') && (Arr[i + 1, j - 1] == 'A') && (Arr[i + 1, j + 1] == 'A'))
                    {
                        CountCross = CountCross + 1;
                        Console.WriteLine("{0} {1} {2} {3} {4}\n", (N * (i) + ((j) + 1)), (N * (i - 1) + ((j - 1) + 1)), (N * (i - 1) + ((j + 1) + 1)), (N * (i + 1) + ((j - 1) + 1)), (N * (i + 1) + ((j + 1) + 1)));
                    }
                }
            }
            Console.Write(CountPlus);
            Console.WriteLine("\n");
            Console.Write(CountCross);

        }

    }
}

﻿CREATE TABLE [dbo].[Color] (
    [Id]    INT        NOT NULL,
    [Title] NCHAR (10) NOT NULL, 
    CONSTRAINT [PK_Color] PRIMARY KEY ([Id])
);


﻿CREATE TABLE [dbo].[Size] (
    [Id]    INT        NOT NULL,
    [Title] NCHAR (10) NOT NULL, 
    CONSTRAINT [PK_Size] PRIMARY KEY ([Id])
);


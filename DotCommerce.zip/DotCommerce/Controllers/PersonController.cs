﻿using DotCommerce.Models;
using System.Data;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace DotCommerce.Controllers
{
    public class PersonController : Controller
    {
        private DotCommerceDataEntities db = new DotCommerceDataEntities();

        // GET: People
        public ActionResult Index()
        {
            if (Session["Email"] != null)
            {
                return View();
            }
            return RedirectToAction("Register");
        }

        // GET: People/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Person person = db.Person.Find(id);
            if (person == null)
            {
                return HttpNotFound();
            }
            return View(person);
        }

        // GET: People/Create
        //public ActionResult Create()
        //{
        //    return View();
        //}

        // POST: People/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "Id,FirstName,LastName,Email,Password,Address,CPassword")] Person person)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Person.Add(person);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    return View(person);
        //}

        // GET: People/Edit/5
        //public ActionResult Edit(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Person person = db.Person.Find(id);
        //    if (person == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(person);
        //}

        // POST: People/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Edit([Bind(Include = "Id,FirstName,LastName,Email,Password,Address,CPassword")] Person person)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Entry(person).State = EntityState.Modified;
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(person);
        //}

        // GET: People/Delete/5
        //public ActionResult Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Person person = db.Person.Find(id);
        //    if (person == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(person);
        //}

        // POST: People/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    Person person = db.Person.Find(id);
        //    db.Person.Remove(person);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register([Bind(Include = "FirstName,LastName,Email,Password,CPassword")] Person person)
        {
            if (ModelState.IsValid)
            {
                //if (!db.Person.Any(u => u.Email == person.Email))
                //{
                db.Person.Add(person);
                db.SaveChanges();
                return View("Index");
                //}
                //else return new HttpStatusCodeResult(HttpStatusCode.NotAcceptable);
            }

            return View(person);
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Person person)
        {
            if (ModelState.IsValid)
            {
                var p = db.Person.Where(a => a.Email.Equals(person.Email) && a.Password.Equals(person.Password)).FirstOrDefault();
                if (p != null)
                {
                    Session["Email"] = p.Email.ToString();
                    Session["Password"] = p.Password.ToString();
                    return RedirectToAction("Index");
                }
            }
            return View(person);
        }
        [HttpGet]
        public JsonResult IsExist(string email)
        {

            bool _isExist = db.Person.Where(u => u.Email.ToLowerInvariant().Equals(email.ToLower())) != null;
            return Json(!_isExist, JsonRequestBehavior.AllowGet);
        }
    }
}

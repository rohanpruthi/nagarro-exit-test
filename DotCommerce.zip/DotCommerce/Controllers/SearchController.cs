﻿using DotCommerce.Models;
using System;
using System.Linq;
using System.Web.Mvc;

namespace DotCommerce.Controllers
{
    public class SearchController : Controller
    {
        private DotCommerceDataEntities db = new DotCommerceDataEntities();
        // GET: Search
        public ActionResult Search(string searchString)
        {
            var product = from s in db.Product
                          select s;
            ViewBag.NoSearch = null;
            if (!String.IsNullOrEmpty(searchString))
            {
                product = product.Where(s => s.Title.Contains(searchString)
                        || s.Description.Contains(searchString));
                if (product.Count() == 0)
                {
                    ViewBag.NoSearch = "No product(s) match the search criteria";
                }
                return View("SearchResults", product.ToList());
            }
            return View("SearchResults");
        }
    }
}